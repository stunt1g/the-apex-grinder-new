//includes
#include <sstream>
#include <sys/uio.h>
#include <math.h>
#include <cmath>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <string>
#include <unistd.h>
#include <vector>
#include <unordered_map>
#include <chrono>
#include <thread>
#include <random>
#include <fstream>
#include <sys/stat.h>
#include <algorithm>
#include <cctype>
#include <locale>
#include <iterator>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/XTest.h>
#include <X11/extensions/Xrender.h>
#include <X11/extensions/Xcomposite.h>
#include <X11/extensions/XInput2.h>
#include <limits>
#include <cstdint>
#include <map>
#include <array>


#include "FloatVector2D.hpp"
#include "FloatVector3D.hpp"
#include "Memory.hpp" 
#include "Offsets.hpp"
#include "QAngle.hpp"
#include "Resolver.hpp"

#include "XDisplay.hpp"
#include "ConfigLoader.hpp"
#include "WeaponId.hpp"

#include "Structs.hpp"

#include "LocalPlayer.hpp"
#include "Player.hpp"
//#include "Aim.hpp"
#include "AimBot.hpp"
#include "NoRecoil.hpp"
#include "Random.hpp"
#include "Sense.hpp"
#include "TriggerBot.hpp"
#include "Radar.hpp"